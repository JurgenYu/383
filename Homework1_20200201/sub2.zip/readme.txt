Huwei(Jurgen)Yu
My aunt's new year dinner
Greedt best-fisrt are the most efficient, I thought it always prefers to move closer to the solution, but astar provides the best solution while maintians
great efficiency, especially for astar-manhat thus I personally think it would be better. 
Ucost is notoriously inefficient because sometimes it kills my patience before concluding the solution.
Manhattan is significantly faster in serveral tests, sometimes it costs below half of the counting method. But both of then increased speed in a notable scale.
Nothing goes wrong, I hope, and I observed. Nothing deserves notice.