Huwei(Jurgen)Yu
My aunt's new year dinner
Greedy best-fisrt are the most efficient, I assume it always prefers to move closer to the solution, but astar provides the best solution while maintians great efficiency, especially for astar-manhat thus I personally think it would be better. 
Ucost is notoriously inefficient because sometimes it kills my patience before concluding the solution (that was when I use OrderedDict, now it's better using heapq, but still).
Manhattan is significantly faster in serveral tests, sometimes it costs below half of the counting method. But both of then boosts the speed in a notable scale.
Nothing goes wrong, I hope, and I observed. Onething to notice, After switch back to heapq instaed of OderedDict in ucost, is's way more faster, but I didn't change the ODs in methods other than ucost so they might actually be slower.